---
name: Enhancement Request
about: Suggest an enhancement to Agola
labels: enhancement

---
<!--

Please only use this template for submitting enhancement requests

-->

**What would you like to be added**:

**Why is this needed**: